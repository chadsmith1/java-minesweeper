package CS2410.Assn8.Gui;

import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;

/**
 * Created by chadsmith on 12/7/16.
 */
public class GameMenu extends MenuBar {
    private Menu settingsMenu;
    private Menu settingsMenuSize;
    private MenuItem size20x20;
    private MenuItem size10x10;
    private MenuItem size7x7;
    private Menu settingsMenuMines;
    private MenuItem mines100;
    private MenuItem mines50;
    private MenuItem mines10;

    private Menu miscMenu;
    private Menu musicMenu;
    private MenuItem noMusic;
    private MenuItem music1;
    private MenuItem music2;
    private MenuItem music3;

    public GameMenu(){

    }
}
