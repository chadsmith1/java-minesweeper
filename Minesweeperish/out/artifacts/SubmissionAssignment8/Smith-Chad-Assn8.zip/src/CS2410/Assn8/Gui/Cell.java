package CS2410.Assn8.Gui;

import CS2410.Assn8.Control.SpotOfCell;
import javafx.scene.control.Button;

/**
 * So This Class is the getter/setter method class that gets all of the cells characteristics and assigns it to the specific
 * css styling that is set in the css folder
 */
public class Cell extends Button {

    private boolean isMine = false;
    private boolean isClicked = false;
    private boolean isFlagged = false;
    private boolean isQuestioned = false;
    private Integer neighbors = 0;
    private SpotOfCell spotOfCell = new SpotOfCell();

    public Cell() {
        setPrefHeight(25);
        setPrefWidth(25);
        getStylesheets().addAll("file:css/custom.css");
        setId("cell-button");
    }

    public void setDefaultCell() {

        getStylesheets().addAll("file:css/custom.css");
        setId("cell-button");
        isQuestioned = false;
        isFlagged = false;
    }

    public void setCellSpot (int x, int y){

        spotOfCell.set(x, y);
    }
    public SpotOfCell getCellSpot() {
        return spotOfCell;
    }

    public void setIsMine() {
         isMine = true;
    }
    public boolean getIsMine() {
        return isMine;
    }

    public void setIsFlagged() {
        isFlagged = true;
    }
    public boolean getIsFlagged() {
        return isFlagged;
    }

    public void setIsClicked() {
        isClicked = true;
    }
    public boolean getIsClicked() {
        return isClicked;
    }

    public void setIsQuestioned() {
        isQuestioned = true;
    }
    public boolean getIsQuestioned() {
        return isQuestioned;
    }

    public void setNeighbor (int neighbors) {
        this.neighbors = neighbors;
    }
    public Integer getNeighbors() {
        return neighbors;
    }

    public void findNeighbors(Integer mines) {

        setIsClicked();

        switch (mines) {

            case 0:
                this.getStylesheets().addAll("file:css/custom.css");
                this.setId("zero-button");
                break;

            case 1:
                this.getStylesheets().addAll("file:css/custom.css");
                this.setId("one-button");
                break;

            case 2:
                this.getStylesheets().addAll("file:css/custom.css");
                this.setId("two-button");
                break;

            case 3:
                this.getStylesheets().addAll("file:css/custom.css");
                this.setId("three-button");
                break;

            case 4:
                this.getStylesheets().addAll("file:css/custom.css");
                this.setId("four-button");
                break;

            case 5:
                this.getStylesheets().addAll("file:css/custom.css");
                this.setId("five-button");
                break;

            case 6:
                this.getStylesheets().addAll("file:css/custom.css");
                this.setId("six-button");
                break;

            case 7:
                this.getStylesheets().addAll("file:css/custom.css");
                this.setId("seven-button");
                break;

            case 8:
                this.getStylesheets().addAll("file:css/custom.css");
                this.setId("eight-button");
                break;
        }
    }

    public String toString() {

        return spotOfCell.toString();
    }
}
