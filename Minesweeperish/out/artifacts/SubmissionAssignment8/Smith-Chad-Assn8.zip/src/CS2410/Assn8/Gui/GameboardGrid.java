package CS2410.Assn8.Gui;

import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.layout.GridPane;
import java.util.ArrayList;
import static java.util.Collections.shuffle;

/**
 * Created by chadsmith on 12/6/16.
 */
public class GameboardGrid extends GridPane {

    private Cell cell;
    private ArrayList<Cell> arrayOfCells = new ArrayList<>();
    private int rows = 20;
    private int columns = 20;
    private int mines = 100;
    private int normalCells = 400;
    private Cell grid[][] = new Cell[rows][columns];

    public GameboardGrid(EventHandler handler) {
        setGameboard(handler);
        setMinesInGrid();
        this.setAlignment(Pos.CENTER);
    }
    /**
     * The "setGameboard" method is what makes the gameboard of minesweeper. This method writes each
     * of the cells and each of the mines to the the "arrayOfCells" which is shuffled afterwards, and
     * lastly the cells in "arrayOfCells is assigned onto the grid.
     */
    private void setGameboard (EventHandler handler) {

        for (int m = 0; m < mines; m++){
            cell = new Cell();
            cell.setIsMine();
            cell.setOnMousePressed(handler);
            arrayOfCells.add(cell);
        }

        for (int n = 0; n < normalCells; n++){
            cell = new Cell();
            cell.setOnMousePressed(handler);
            arrayOfCells.add(cell);
        }

        shuffle(arrayOfCells);

        int totalCount = 0;
        for(int y = 0; y < columns; y++){

            for(int x = 0; x < rows; x++){
                grid[x][y] = arrayOfCells.get(totalCount);
                this.add(arrayOfCells.get(totalCount), x, y);
                grid[x][y].setCellSpot(x, y);

                totalCount++;
            }
        }
    }

    /**
     *This method what it does is that it gets the position of a cell, and it cycles through it's
     * eight neighbors to see if any of them are mines. If they are a mine then the int "neighboringCell"
     * will get incremented the value plus one.
     */
    private int countNeighboringMines (int x, int y) {

        int neighboringCell = 0;

        for (int i = y - 1; i <= y + 1; i++) {

            for (int j = x - 1; j <= x + 1; j++) {

                if (i >= 0 && i < 20 && j >= 0 && j < 20 && (j != x || i != y) && grid[j][i].getIsMine()) {
                    neighboringCell++;
                }
            }
        }
        return neighboringCell;
    }

    /**
     * This "setMinesInGrid" method goes through the entire grid and performs the "countNeighborMines" on each of the positions
     * in the grid.
     */
    private void setMinesInGrid() {

        for(int y = 0; y < columns; y++){
            for (int x = 0; x < rows; x++){
                grid[x][y].setNeighbor(countNeighboringMines(x,y));
            }
        }
    }

    /**
     * This "getGrid()" method just returns the new updated grid.
     */
    public Cell[][] getGrid() {
        return grid;
    }
}