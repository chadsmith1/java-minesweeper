package CS2410.Assn8.Control;

import CS2410.Assn8.Gui.Cell;
import CS2410.Assn8.Gui.GameboardGrid;
import CS2410.Assn8.Gui.Scoreboard;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.scene.control.Alert;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;

import java.util.Timer;
import java.util.TimerTask;

/**
 * This is the Control Class, it's the class that basically puts it all together.
 * In this class you will find the method for starting the game timer.
 */
public class Control extends BorderPane {

    private Timer gameTimer = new Timer();
    private EventHandler<MouseEvent> eventhandler = event -> clickedCell(event.getButton(), (Cell) event.getSource());
    private Integer uncoveredCells = 0;
    private GameboardGrid grid;
    private Scoreboard scoreboard;
    private Cell cells[][] = new Cell[20][20];

    public Control() {
        initControl();

    }

    private void initControl() {
        uncoveredCells = 0;
        scoreboard = new Scoreboard();
        grid = new GameboardGrid(eventhandler);
        gameTimer = new Timer();
        cells = grid.getGrid();
        this.setCenter(grid);
        this.setTop(scoreboard);
        bt_StartAction();
    }

    private void startGameTimer() {

        scoreboard.bt_StartDisabled(true);
        gameTimer.scheduleAtFixedRate(new TimerTask() {
            @Override

            public void run() {
                Platform.runLater(new Runnable() {

                    @Override
                    public void run() {

                        scoreboard.plusTime();
                    }
                });
            }
        }, 0, 500);
    }

    public void endTimer() {
        gameTimer.cancel();
    }

    private void bt_StartAction() {
    scoreboard.setStart(e ->

        initControl());
    }

    private void userWins() {
        endTimer();

        for (int y = 0; y < 20; y++){

            for (int x = 0; x < 20; x++){
                cells[x][y].setIsClicked();
                if (cells[x][y].getIsMine()){
                    cells[x][y].getStylesheets().addAll("file:css/custom.css");
                    cells[x][y].setId("good-mines");
                }
            }
        }

        ImageView winningView = new ImageView("file:data/win.gif");
        winningView.setFitWidth(250);
        winningView.setPreserveRatio(true);

        Alert winner = new Alert(Alert.AlertType.INFORMATION);
        winner.setTitle("Feelin Like Pablo?");
        winner.setGraphic(winningView);
        winner.setContentText("Congratulations!!!! you won in " + scoreboard.getTime().toString() + " seconds.");
        winner.showAndWait();
        scoreboard.bt_StartDisabled(false);
    }

    private void winner() {
        if (uncoveredCells == 300){
            userWins();
        }
    }

    private void lose() {
        endTimer();

        for(int y = 0; y < 20; y++) {
            for(int x = 0; x < 20; x++) {

                if(cells[x][y].getIsMine() && (cells[x][y].getIsFlagged() || cells[x][y].getIsQuestioned())) {
                    cells[x][y].getStylesheets().addAll("file:css/custom.css");
                    cells[x][y].setId("correct-button");
                }

                if(cells[x][y].getIsMine() && !cells[x][y].getIsFlagged() && !cells[x][y].getIsQuestioned()) {
                    cells[x][y].getStylesheets().addAll("file:css/custom.css");
                    cells[x][y].setId("cleared-button");
                }

                if(!cells[x][y].getIsMine() && cells[x][y].getIsFlagged() || cells[x][y].getIsQuestioned()) {
                    cells[x][y].getStylesheets().addAll("file:css/custom.css");
                    cells[x][y].setId("wrong-button");
                }
            }

            ImageView loserView = new ImageView("file:data/youlost.png");
            loserView.setFitWidth(250);
            loserView.setPreserveRatio(true);

            Alert loser = new Alert(Alert.AlertType.INFORMATION);
            loser.setTitle("Not Feeling Like Pablo");
            loser.setGraphic(loserView);
            loser.setContentText("Better luck next time!!!\n\n You lost in: " + scoreboard.getTime().toString() + " seconds");
            loser.showAndWait();
            scoreboard.bt_StartDisabled(false);
        }
    }

    private void clickedCell(MouseButton button, Cell cell) {

        if(uncoveredCells == 0 && button == MouseButton.PRIMARY){
            startGameTimer();
        }

        if (!cell.getIsClicked()) {
            if(button == MouseButton.SECONDARY){
                if (!cell.getIsFlagged() && !cell.getIsQuestioned()) {
                    cell.setIsFlagged();
                    scoreboard.minusMinesLeft();
                }
                else if (cell.getIsFlagged() && !cell.getIsQuestioned()) {
                    cell.setIsQuestioned();
                }
                else if (!cell.getIsFlagged() && cell.getIsQuestioned()) {
                    cell.setDefaultCell();
                    scoreboard.plusMinesLeft();
                }
            }
        }

        if (button == MouseButton.PRIMARY) {
            if (!cell.getIsFlagged() && !cell.getIsQuestioned() && !cell.getIsMine()){
                cell.findNeighbors(cell.getNeighbors());
                uncoveredCells++;
                winner();
                setNeighbors(cell.getCellSpot().x, cell.getCellSpot().y);
            }

            if (cell.getIsMine()){
                lose();
            }
        }
    }

    private void setNeighbors(int x, int y) {

        if (cells[x][y].getNeighbors() != 0 ){
            return;
        }

        if (x >= 0 && x < 19 && y >= 0 && y < 20 && !cells[x + 1][y].getIsMine()){
            clickedCell(MouseButton.PRIMARY, cells[x + 1][y]);
        }

        if (x >= 0 && x < 20 && y >= 0 && y < 20 && !cells[x - 1][y].getIsMine()){
            clickedCell(MouseButton.PRIMARY, cells[x - 1][y]);
        }

        if (x >= 0 && x < 19 && y >= 0 && y < 20 && !cells[x][y + 1].getIsMine()){
            clickedCell(MouseButton.PRIMARY, cells[x][y + 1]);
        }

        if (x >= 0 && x < 20 && y > 0 && y < 20 && !cells[x][y - 1].getIsMine()){
            clickedCell(MouseButton.PRIMARY, cells[x][y - 1]);
        }
    }
}
