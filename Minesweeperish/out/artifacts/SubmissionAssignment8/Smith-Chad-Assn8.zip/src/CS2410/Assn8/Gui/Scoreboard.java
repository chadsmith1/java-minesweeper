package CS2410.Assn8.Gui;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

/**
 * This Class is for the Scoreboard. It holds the timer, the Start Button, and how many mines
 * are remaining in the game.
 */
public class Scoreboard extends HBox {

    private Button bt_Start = new Button("Start");

    private Integer minesLeft = 100;
    private Integer time = 0;
    private Label lb_MinesLeft = new Label();
    private Label lb_Time = new Label();
    private SimpleIntegerProperty minesLeftProperty = new SimpleIntegerProperty(minesLeft);
    private SimpleIntegerProperty timeProperty = new SimpleIntegerProperty(time);

    public Scoreboard() {

        this.setPadding(new Insets(25,75, 25, 75));
        this.setSpacing(25);

        bt_Start.setPrefWidth(150);
        bt_Start.getStylesheets().addAll("file:css/custom.css");
        bt_Start.setId("start-button");

        VBox vboxTime = new VBox(new Label("Time: "), lb_Time);
        VBox vboxMines = new VBox(new Label("Mines Left: "), lb_MinesLeft);

        vboxTime.setAlignment(Pos.CENTER);
        vboxTime.setStyle("-fx-font-size: 18");

        vboxMines.setAlignment(Pos.CENTER);
        vboxMines.setStyle("-fx-font-size: 18");

        lb_Time.textProperty().bind(timeProperty.asString());
        lb_MinesLeft.textProperty().bind(minesLeftProperty.asString());

        this.getChildren().addAll(vboxMines, bt_Start, vboxTime);
        this.setAlignment(Pos.CENTER);
        this.setSpacing(50);
        this.setPadding(new Insets(25));
    }

    public void plusTime() {
        timeProperty.set(time++);
    }

    public void plusMinesLeft() {
        minesLeftProperty.set(minesLeft++);
    }

    public void minusMinesLeft() {
        minesLeftProperty.set(minesLeft--);
    }

    public void setStart(EventHandler<ActionEvent> event){
        bt_Start.setOnAction(event);
    }

    public Integer getTime() {
        return time--;
    }

    public void bt_StartDisabled (boolean startIsOn) {

        bt_Start.setDisable(startIsOn);
    }
}
