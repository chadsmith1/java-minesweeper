package CS2410.Assn8.Gui;

import javafx.application.Application;
import CS2410.Assn8.Control.Control;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * This Class is the Main Game class. This class calls the border pane that contains all the other
 * panes that are used in this application of minesweeper
 *
 * @author Chad
 * @version XXX
 */
public class MainGame extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {

        Control mainPane = new Control();
        Scene scene = new Scene(mainPane);

        primaryStage.setTitle("Assignment 8: MineSweeper");
        primaryStage.setMinHeight(700);
        primaryStage.setMinWidth(875);
        primaryStage.setResizable(false);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
