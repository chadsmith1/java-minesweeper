package CS2410.Assn8.Control;

/**
 * This Class assigns the cells a certain spot on the grid. This class grabs the position and sets the Button/Cell
 * to that spot
 */

public class SpotOfCell {
    public Integer x;
    public Integer y;

    public void set(int x, int y) {

        this.x = x;
        this.y = y;
    }

    public String spotToString () {

        return x.toString() + ", " + y.toString();
    }
}
